# South-vs-North-major-swap
Failing a class? Having a mid-quarter crisis? Switch to north campus!
